<?php
$name='ind_ml_1_001';
$type='TTF';
$desc=array (
  'Ascent' => 742,
  'Descent' => -469,
  'CapHeight' => 742,
  'Flags' => 4,
  'FontBBox' => '[-500 -454 2003 756]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$up=-113;
$ut=57;
$ttffile='/home/court/ciswork1/MPDF/ttfonts/ind_ml_1_001.ttf';
$TTCfontID='0';
$originalsize=115804;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='ind_ml_1_001';
$panose=' 0 0 2 b 6 6 3 8 4 2 2 4';
$kerninfo=array (
);
$haskerninfo=true;
$unAGlyphs=false;
?>